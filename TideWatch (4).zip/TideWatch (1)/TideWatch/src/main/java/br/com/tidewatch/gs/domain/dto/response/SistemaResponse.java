package br.com.tidewatch.gs.domain.dto.response;

import lombok.Builder;

@Builder
public record SistemaResponse(
        Long id,
        String descricao,
        String status,
        String tipo
) {
}
