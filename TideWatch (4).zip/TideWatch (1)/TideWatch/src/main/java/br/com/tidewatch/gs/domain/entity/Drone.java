package br.com.tidewatch.gs.domain.entity;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.LinkedHashSet;
import java.util.Set;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder

@Entity
@Table(name = "T_DRONE")
public class Drone {

    @Id
    @SequenceGenerator(name = "SQ_DRONE", sequenceName = "SQ_DRONE", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SQ_DRONE")
    @Column(name = "ID_DRONE")
    private Long id;

    @Column(name = "ST_DRONE")
    private String status;

    @Column(name = "LOC_ATUAL")
    private String localizacaoAtual;

    @Column(name = "MODELO_DRONE")
    private String modeloDrone;

    @ManyToOne(fetch = FetchType.EAGER, cascade = {CascadeType.PERSIST, CascadeType.MERGE})
    @JoinColumn(
            name = "SISTEMA",
            referencedColumnName = "ID_SISTEMA",
            foreignKey = @ForeignKey(
                    name = "FK_DRONE_SISTEMA"
            )
    )
    private Sistema sistema;

    @ManyToMany(fetch = FetchType.EAGER, cascade = {CascadeType.MERGE, CascadeType.PERSIST})
    @JoinTable(
            name = "T_DRONE_LOCALIZACAO",
            joinColumns = {
                    @JoinColumn(
                            name = "DRONE",
                            referencedColumnName = "ID_DRONE",
                            foreignKey = @ForeignKey(
                                    name = "FK_DRONE_LOCALIZACAO"
                            )
                    )
            },
            inverseJoinColumns = {
                    @JoinColumn(
                            name = "LOCALIZACAO",
                            referencedColumnName = "ID_LOCALIZACAO",
                            foreignKey = @ForeignKey(
                                    name = "FK_LOCALIZACAO_DRONE"
                            )
                    )
            }


    )
    private Set<Localizacao> localizacao = new LinkedHashSet<>();


}
