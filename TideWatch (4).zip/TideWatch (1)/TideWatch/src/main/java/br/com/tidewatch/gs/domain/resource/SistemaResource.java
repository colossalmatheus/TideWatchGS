package br.com.tidewatch.gs.domain.resource;

import br.com.tidewatch.gs.domain.dto.request.SistemaRequest;
import br.com.tidewatch.gs.domain.dto.response.SistemaResponse;
import br.com.tidewatch.gs.domain.entity.Sistema;
import br.com.tidewatch.gs.domain.service.SistemaService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.util.Collection;
import java.util.Objects;

@RestController
@RequestMapping(value = "/sistema")
public class SistemaResource implements ResourceDTO<SistemaRequest, SistemaResponse> {

    @Autowired
    private SistemaService service;

    @GetMapping
    @Operation(summary = "Listar todos os Sistemas", description = "Lista todos os sistemas com base nos parâmetros de filtro opcionais")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Sucesso"),
            @ApiResponse(responseCode = "400", description = "Parâmetro inválido"),
            @ApiResponse(responseCode = "500", description = "Erro interno do servidor")
    })
    public ResponseEntity<Collection<SistemaResponse>> findAll(
            @Parameter(description = "Descrição do Sistema") @RequestParam(name = "descricao", required = false) final String descricao,
            @Parameter(description = "Status do Sistema") @RequestParam(name = "status", required = false) final String status,
            @Parameter(description = "Tipo do Sistema") @RequestParam(name = "tipo", required = false) final String tipo
    ) {
        var sistema = Sistema.builder()
                .descricao(descricao)
                .status(status)
                .tipo(tipo)
                .build();

        ExampleMatcher matcher = ExampleMatcher
                .matchingAll()
                .withIgnoreNullValues()
                .withIgnoreCase();

        Example<Sistema> example = Example.of(sistema, matcher);

        var entity = service.findAll(example);

        var response = entity.stream().map(service::toResponse).toList();

        return ResponseEntity.ok(response);
    }

    @GetMapping(value = "/{id}")
    @Operation(summary = "Buscar Sistema por ID", description = "Retorna um sistema baseado no ID fornecido")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Sucesso"),
            @ApiResponse(responseCode = "404", description = "Sistema não encontrado"),
            @ApiResponse(responseCode = "500", description = "Erro interno do servidor")
    })
    @Override
    public ResponseEntity<SistemaResponse> findById(@PathVariable @Parameter(description = "ID do Sistema", required = true) final Long id) {
        var entity = service.findById(id);
        if (Objects.isNull(entity)) return ResponseEntity.notFound().build();
        var response = service.toResponse(entity);
        return ResponseEntity.ok(response);
    }

    @Transactional
    @PostMapping
    @Operation(summary = "Criar novo Sistema", description = "Cria um novo sistema com base nos dados fornecidos")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Sistema criado com sucesso"),
            @ApiResponse(responseCode = "400", description = "Dados inválidos fornecidos"),
            @ApiResponse(responseCode = "500", description = "Erro interno do servidor")
    })
    @Override
    public ResponseEntity<SistemaResponse> save(@RequestBody @Valid @Parameter(description = "Dados do Sistema", required = true) SistemaRequest r) {
        var entity = service.toEntity(r);
        var saved = service.save(entity);
        var uri = ServletUriComponentsBuilder.fromCurrentRequestUri()
                .path("/{id}")
                .buildAndExpand(saved.getId())
                .toUri();

        var response = service.toResponse(saved);

        return ResponseEntity.created(uri).body(response);
    }
}
