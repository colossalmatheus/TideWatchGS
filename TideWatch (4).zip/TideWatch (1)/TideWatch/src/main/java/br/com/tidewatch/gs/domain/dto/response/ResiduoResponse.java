package br.com.tidewatch.gs.domain.dto.response;

import lombok.Builder;

import java.time.LocalDateTime;

@Builder
public record ResiduoResponse(

        Long id,
        DroneResponse drone,
        LocalDateTime coleta,
        String quantidade,
        String residuos,
        String tipo

) {
}
