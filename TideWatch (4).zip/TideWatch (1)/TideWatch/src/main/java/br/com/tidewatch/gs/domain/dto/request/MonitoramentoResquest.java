package br.com.tidewatch.gs.domain.dto.request;

import jakarta.validation.constraints.NotNull;

public record MonitoramentoResquest(

        String descricao,

        @NotNull(message = "Informe o drone")
        AbstractRequest drone,

        @NotNull(message = "Informe o status")
        String status
) {
}
