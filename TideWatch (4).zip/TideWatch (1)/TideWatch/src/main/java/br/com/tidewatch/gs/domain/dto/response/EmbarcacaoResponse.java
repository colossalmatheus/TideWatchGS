package br.com.tidewatch.gs.domain.dto.response;

import lombok.Builder;

import java.util.Collection;

@Builder
public record EmbarcacaoResponse(
        Long id,
        String descricao,
        String nome,
        Collection<ResiduoResponse> residuos,

        Collection<LocalizacaoResponse> localizacao,
        String status,
        String tipo
) {
}
