package br.com.tidewatch.gs.domain.dto.request;

import jakarta.validation.constraints.NotNull;

public record LocalizacaoRequest(

        @NotNull(message = "Informe a descrição")
        String descricao,

        @NotNull(message = "Informe a latitude")
        String latitude,

        @NotNull(message = "Informe a longitude")
        String longitude
) {
}
