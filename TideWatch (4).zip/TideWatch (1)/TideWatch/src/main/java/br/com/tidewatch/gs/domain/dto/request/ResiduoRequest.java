package br.com.tidewatch.gs.domain.dto.request;

import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotNull;

import java.time.LocalDateTime;

public record ResiduoRequest(


        LocalDateTime coleta,

        AbstractRequest drone,

        @NotNull(message = "Informe a quantidade")
        String quantidade,

        @NotNull(message = "Informe a descricao do residuos")
        String residuos,

        @NotNull(message = "Informe o tipo")
        String tipo


) {
}
