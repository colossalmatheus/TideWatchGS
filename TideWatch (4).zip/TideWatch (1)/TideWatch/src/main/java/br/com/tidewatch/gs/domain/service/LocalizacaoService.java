package br.com.tidewatch.gs.domain.service;

import br.com.tidewatch.gs.domain.dto.request.LocalizacaoRequest;
import br.com.tidewatch.gs.domain.dto.response.LocalizacaoResponse;
import br.com.tidewatch.gs.domain.entity.Localizacao;
import br.com.tidewatch.gs.domain.repository.EmbarcacaoRepository;
import br.com.tidewatch.gs.domain.repository.LocalizacaoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Service;

import java.util.Collection;

@Service
public class LocalizacaoService implements ServiceDTO<Localizacao, LocalizacaoRequest, LocalizacaoResponse> {

    @Autowired
    private LocalizacaoRepository repo;
    @Override
    public Collection<Localizacao> findAll() {
        return repo.findAll();
    }

    @Override
    public Collection<Localizacao> findAll(Example<Localizacao> example) {
        return repo.findAll(example);
    }

    @Override
    public Localizacao findById(Long id) {
        return repo.findById( id ).orElse(null);
    }

    @Override
    public Localizacao save(Localizacao e) {
        return repo.save(e);
    }

    @Override
    public Localizacao toEntity(LocalizacaoRequest dto) {
        return Localizacao.builder()
                .descricao(dto.descricao())
                .latitude(dto.latitude())
                .longitude(dto.longitude())
                .build();
    }

    @Override
    public LocalizacaoResponse toResponse(Localizacao e) {
        return LocalizacaoResponse.builder()
                .id(e.getId())
                .descricao(e.getDescricao())
                .latitude(e.getLatitude())
                .longitude(e.getLongitude())
                .build();
    }
}
