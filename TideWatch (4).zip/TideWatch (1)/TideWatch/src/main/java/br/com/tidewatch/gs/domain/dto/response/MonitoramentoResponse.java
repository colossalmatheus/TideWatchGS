package br.com.tidewatch.gs.domain.dto.response;

import lombok.Builder;

@Builder
public record MonitoramentoResponse(

        Long id,
        String descricao,
        DroneResponse drone,
        String status
) {
}
