package br.com.tidewatch.gs.domain.repository;

import br.com.tidewatch.gs.domain.entity.Monitoramento;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MonitoramentoRepository extends JpaRepository<Monitoramento, Long> {
}
