package br.com.tidewatch.gs.domain.resource;

import br.com.tidewatch.gs.domain.dto.request.ResiduoRequest;
import br.com.tidewatch.gs.domain.dto.response.ResiduoResponse;
import br.com.tidewatch.gs.domain.entity.Drone;
import br.com.tidewatch.gs.domain.entity.Residuo;
import br.com.tidewatch.gs.domain.service.ResiduoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.Objects;

@RestController
@RequestMapping(value = "/residuo")
public class ResiduoResource implements ResourceDTO<ResiduoRequest, ResiduoResponse> {

    @Autowired
    private ResiduoService service;

    @GetMapping
    @Operation(summary = "Listar todos os Residuos", description = "Lista todos os resíduos com base nos parâmetros de filtro opcionais")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Sucesso"),
            @ApiResponse(responseCode = "400", description = "Parâmetro inválido"),
            @ApiResponse(responseCode = "500", description = "Erro interno do servidor")
    })
    public ResponseEntity<Collection<ResiduoResponse>> findAll(
            @Parameter(description = "Data de Coleta do Resíduo") @RequestParam(name = "coleta", required = false) final LocalDateTime coleta,
            @Parameter(description = "Quantidade do Resíduo") @RequestParam(name = "quantidade", required = false) final String quantidade,
            @Parameter(description = "Descrição do Resíduo") @RequestParam(name = "residuo", required = false) final String residuo,
            @Parameter(description = "Tipo do Resíduo") @RequestParam(name = "tipo", required = false) final String tipo,
            @Parameter(description = "Modelo do Drone") @RequestParam(name = "drone.modelo", required = false) final String droneModelo
    ) {
        var dro = Drone.builder()
                .modeloDrone(droneModelo)
                .build();
        var res = Residuo.builder()
                .coleta(coleta)
                .quantidade(quantidade)
                .residuos(residuo)
                .drone(dro)
                .tipo(tipo)
                .build();

        ExampleMatcher matcher = ExampleMatcher
                .matchingAll()
                .withIgnoreNullValues()
                .withIgnoreCase();

        Example<Residuo> example = Example.of(res, matcher);

        var entity = service.findAll(example);

        var response = entity.stream().map(service::toResponse).toList();

        return ResponseEntity.ok(response);
    }

    @GetMapping(value = "/{id}")
    @Operation(summary = "Buscar Residuo por ID", description = "Retorna um resíduo baseado no ID fornecido")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Sucesso"),
            @ApiResponse(responseCode = "404", description = "Resíduo não encontrado"),
            @ApiResponse(responseCode = "500", description = "Erro interno do servidor")
    })
    @Override
    public ResponseEntity<ResiduoResponse> findById(@PathVariable @Parameter(description = "ID do Resíduo", required = true) final Long id) {
        var entity = service.findById(id);
        if (Objects.isNull(entity)) return ResponseEntity.notFound().build();
        var response = service.toResponse(entity);
        return ResponseEntity.ok(response);
    }

    @Transactional
    @PostMapping
    @Operation(summary = "Criar novo Residuo", description = "Cria um novo resíduo com base nos dados fornecidos")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Resíduo criado com sucesso"),
            @ApiResponse(responseCode = "400", description = "Dados inválidos fornecidos"),
            @ApiResponse(responseCode = "500", description = "Erro interno do servidor")
    })
    @Override
    public ResponseEntity<ResiduoResponse> save(@RequestBody @Valid @Parameter(description = "Dados do Resíduo", required = true) ResiduoRequest r) {
        var entity = service.toEntity(r);
        var saved = service.save(entity);
        var uri = ServletUriComponentsBuilder.fromCurrentRequestUri()
                .path("/{id}")
                .buildAndExpand(saved.getId())
                .toUri();

        var response = service.toResponse(saved);

        return ResponseEntity.created(uri).body(response);
    }
}
