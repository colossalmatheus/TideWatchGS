package br.com.tidewatch.gs.domain.service;

import br.com.tidewatch.gs.domain.dto.request.DroneRequest;
import br.com.tidewatch.gs.domain.dto.response.DroneResponse;
import br.com.tidewatch.gs.domain.dto.response.LocalizacaoResponse;
import br.com.tidewatch.gs.domain.entity.Drone;
import br.com.tidewatch.gs.domain.entity.Localizacao;
import br.com.tidewatch.gs.domain.repository.DroneRepository;
import br.com.tidewatch.gs.domain.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class DroneService implements ServiceDTO<Drone, DroneRequest, DroneResponse>{

    @Autowired
    private DroneRepository repo;

    @Autowired
    private SistemaService sistemaService;

    @Autowired
    private LocalizacaoService localizacaoService;


    @Override
    public Collection<Drone> findAll() {
        return repo.findAll();
    }

    @Override
    public Collection<Drone> findAll(Example<Drone> example) {
        return repo.findAll(example);
    }

    @Override
    public Drone findById(Long id) {
        return repo.findById( id ).orElse(null);
    }

    @Override
    public Drone save(Drone e) {
        return repo.save(e);
    }

    @Override
    public Drone toEntity(DroneRequest dto) {
        Set<Localizacao> localizacao = new LinkedHashSet<>();
        var sist = sistemaService.findById(dto.sistema().id());
        return Drone.builder()
                .modeloDrone(dto.modeloDrone())
                .localizacaoAtual(dto.localizacaoAtual())
                .status(dto.status())
                .localizacao(localizacao)
                .sistema(sist)
                .build();
    }

    @Override
    public DroneResponse toResponse(Drone e) {
        Collection<LocalizacaoResponse> localizacoes = new LinkedHashSet<>();
        for(var localizacao:e.getLocalizacao()){
            localizacoes.add(localizacaoService.toResponse(localizacao));
        }
        var sist = sistemaService.toResponse(e.getSistema());
        return DroneResponse.builder()
                .id(e.getId())
                .modeloDrone(e.getModeloDrone())
                .status(e.getStatus())
                .localizacaoAtual(e.getLocalizacaoAtual())
                .localizacao(localizacoes)
                .sistema(sist)
                .build();
    }
}
