package br.com.tidewatch.gs.domain.dto.request;

import jakarta.validation.constraints.NotNull;

import java.util.Collection;

public record DroneRequest(

        Collection<AbstractRequest> localizacao,
        @NotNull(message = "Você precisa informar a localização atual")
        String localizacaoAtual,

        @NotNull(message = "Informe o modelo")
        String modeloDrone,
        AbstractRequest sistema,
        @NotNull(message = "Informe o status")
        String status
) {
}
