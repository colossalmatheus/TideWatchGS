package br.com.tidewatch.gs.domain.resource;

import br.com.tidewatch.gs.domain.dto.request.UsuarioRequest;
import br.com.tidewatch.gs.domain.dto.response.UsuarioResponse;
import br.com.tidewatch.gs.domain.entity.Sistema;
import br.com.tidewatch.gs.domain.entity.Usuario;
import br.com.tidewatch.gs.domain.service.UsuarioService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.util.Collection;
import java.util.Objects;

@RestController
@RequestMapping(value = "/usuario")
public class UsuarioResource implements ResourceDTO<UsuarioRequest, UsuarioResponse> {

    @Autowired
    private UsuarioService service;

    @GetMapping
    @Operation(summary = "Listar todos os Usuários", description = "Lista todos os usuários com base nos parâmetros de filtro opcionais")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Sucesso"),
            @ApiResponse(responseCode = "400", description = "Parâmetro inválido"),
            @ApiResponse(responseCode = "500", description = "Erro interno do servidor")
    })
    public ResponseEntity<Collection<UsuarioResponse>> findAll(
            @Parameter(description = "Descrição do Usuário") @RequestParam(name = "descricao", required = false) final String descricao,
            @Parameter(description = "Nome do Usuário") @RequestParam(name = "nome", required = false) final String nome,
            @Parameter(description = "Descrição do Sistema") @RequestParam(name = "sistema.descricao", required = false) final String sistemaDescricao
    ) {
        var sistema = Sistema.builder()
                .descricao(sistemaDescricao)
                .build();

        var user = Usuario.builder()
                .nome(nome)
                .descricao(descricao)
                .sistema(sistema)
                .build();

        ExampleMatcher matcher = ExampleMatcher
                .matchingAll()
                .withIgnoreNullValues()
                .withIgnoreCase();

        Example<Usuario> example = Example.of(user, matcher);

        var entity = service.findAll(example);

        var response = entity.stream().map(service::toResponse).toList();

        return ResponseEntity.ok(response);
    }

    @GetMapping(value = "/{id}")
    @Operation(summary = "Buscar Usuário por ID", description = "Retorna um usuário baseado no ID fornecido")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Sucesso"),
            @ApiResponse(responseCode = "404", description = "Usuário não encontrado"),
            @ApiResponse(responseCode = "500", description = "Erro interno do servidor")
    })
    @Override
    public ResponseEntity<UsuarioResponse> findById(@PathVariable @Parameter(description = "ID do Usuário", required = true) final Long id) {
        var entity = service.findById(id);
        if (Objects.isNull(entity)) return ResponseEntity.notFound().build();
        var response = service.toResponse(entity);
        return ResponseEntity.ok(response);
    }

    @Transactional
    @PostMapping
    @Operation(summary = "Criar novo Usuário", description = "Cria um novo usuário com base nos dados fornecidos")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Usuário criado com sucesso"),
            @ApiResponse(responseCode = "400", description = "Dados inválidos fornecidos"),
            @ApiResponse(responseCode = "500", description = "Erro interno do servidor")
    })
    @Override
    public ResponseEntity<UsuarioResponse> save(@RequestBody @Valid @Parameter(description = "Dados do Usuário", required = true) UsuarioRequest r) {
        var entity = service.toEntity(r);
        var saved = service.save(entity);
        var uri = ServletUriComponentsBuilder.fromCurrentRequestUri()
                .path("/{id}")
                .buildAndExpand(saved.getId())
                .toUri();

        var response = service.toResponse(saved);

        return ResponseEntity.created(uri).body(response);
    }
}
