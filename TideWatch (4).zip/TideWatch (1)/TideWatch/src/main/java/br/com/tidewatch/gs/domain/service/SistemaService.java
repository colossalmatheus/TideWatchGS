package br.com.tidewatch.gs.domain.service;

import br.com.tidewatch.gs.domain.dto.request.SistemaRequest;
import br.com.tidewatch.gs.domain.dto.response.SistemaResponse;
import br.com.tidewatch.gs.domain.entity.Sistema;
import br.com.tidewatch.gs.domain.repository.ResiduoRepository;
import br.com.tidewatch.gs.domain.repository.SistemaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Service;

import java.util.Collection;

@Service
public class SistemaService implements ServiceDTO<Sistema, SistemaRequest,SistemaResponse> {

    @Autowired
    private SistemaRepository repo;

    @Override
    public Collection<Sistema> findAll() {
        return repo.findAll();
    }

    @Override
    public Collection<Sistema> findAll(Example<Sistema> example) {
        return repo.findAll(example);
    }

    @Override
    public Sistema findById(Long id) {
        return repo.findById( id ).orElse(null);
    }

    @Override
    public Sistema save(Sistema e) {
        return repo.save(e);
    }

    @Override
    public Sistema toEntity(SistemaRequest dto) {
        return Sistema.builder()
                .descricao(dto.descricao())
                .status(dto.Status())
                .tipo(dto.tipo())
                .build();
    }

    @Override
    public SistemaResponse toResponse(Sistema e) {
        return SistemaResponse.builder()
                .id(e.getId())
                .descricao(e.getDescricao())
                .status(e.getStatus())
                .tipo(e.getTipo())
                .build();
    }
}
