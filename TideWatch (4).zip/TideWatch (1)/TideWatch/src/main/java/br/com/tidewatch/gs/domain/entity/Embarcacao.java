package br.com.tidewatch.gs.domain.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.LinkedHashSet;
import java.util.Set;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder

@Entity
@Table(name = "T_EMBARCACAO")
public class Embarcacao {

    @Id
    @SequenceGenerator(name = "SQ_EMBARCACAO", sequenceName = "SQ_EMBARCACAO", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SQ_EMBARCACAO")
    @Column(name = "ID_EMBARCACAO")
    private Long id;

    @Column(name = "NM_EMBARCACAO")
    private String nome;

    @Column(name = "TP_EMBARCACAO")
    private String tipo;

    @Column(name = "ST_EMBARCACAO")
    private String status;

    @Column(name = "DS_EMBARCACAO")
    private String descricao;

    @ManyToMany(fetch = FetchType.EAGER, cascade = {CascadeType.MERGE, CascadeType.PERSIST})
    @JoinTable(
            name = "T_EMBARCACAO_LOCALIZACAO",
            joinColumns = {
                    @JoinColumn(
                            name = "EMBARCACAO",
                            referencedColumnName = "ID_EMBARCACAO",
                            foreignKey = @ForeignKey(
                                    name = "FK_EMBARCACAO_LOCALIZACAO"
                            )
                    )
            },
            inverseJoinColumns = {
                    @JoinColumn(
                            name = "LOCALIZACAO",
                            referencedColumnName = "ID_LOCALIZACAO",
                            foreignKey = @ForeignKey(
                                    name = "FK_LOCALIZACAO_EMBARCACAO"
                            )
                    )
            }


    )
    private Set<Localizacao> localizacao = new LinkedHashSet<>();

    @ManyToMany(fetch = FetchType.EAGER, cascade = {CascadeType.MERGE, CascadeType.PERSIST})
    @JoinTable(
            name = "T_EMBARCACAO_RESIDUO",
            joinColumns = {
                    @JoinColumn(
                            name = "EMBARCACAO",
                            referencedColumnName = "ID_EMBARCACAO",
                            foreignKey = @ForeignKey(
                                    name = "FK_EMBARCACAO_RESIDUO"
                            )
                    )
            },
            inverseJoinColumns = {
                    @JoinColumn(
                            name = "RESIDUOS",
                            referencedColumnName = "ID_RESIDUOS",
                            foreignKey = @ForeignKey(
                                    name = "FK_RESIDUOS_EMBARCACAO"
                            )
                    )
            }


    )
    private Set<Residuo> residuos = new LinkedHashSet<>();


}
