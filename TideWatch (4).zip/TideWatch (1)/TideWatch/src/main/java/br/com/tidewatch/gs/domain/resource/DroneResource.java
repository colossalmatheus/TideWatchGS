package br.com.tidewatch.gs.domain.resource;

import br.com.tidewatch.gs.domain.dto.request.AbstractRequest;
import br.com.tidewatch.gs.domain.dto.request.DroneRequest;
import br.com.tidewatch.gs.domain.dto.response.DroneResponse;
import br.com.tidewatch.gs.domain.entity.Drone;
import br.com.tidewatch.gs.domain.entity.Localizacao;
import br.com.tidewatch.gs.domain.entity.Sistema;
import br.com.tidewatch.gs.domain.service.DroneService;
import br.com.tidewatch.gs.domain.service.LocalizacaoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.util.*;

@RestController
@RequestMapping(value = "/drone")
public class DroneResource implements ResourceDTO<DroneRequest, DroneResponse> {

    @Autowired
    private DroneService service;

    @Autowired
    private LocalizacaoService localizacaoService;

    @GetMapping
    @Operation(summary = "Listar todos os Drones", description = "Lista todos os drones com base nos parâmetros de filtro opcionais")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Sucesso"),
            @ApiResponse(responseCode = "400", description = "Parâmetro inválido"),
            @ApiResponse(responseCode = "500", description = "Erro interno do servidor")
    })
    public ResponseEntity<Collection<DroneResponse>> findAll(
            @Parameter(description = "Localização Atual do Drone") @RequestParam(name = "localizacaoAtual", required = false) final String localizacaoAtual,
            @Parameter(description = "Modelo do Drone") @RequestParam(name = "modelo", required = false) final String modelo,
            @Parameter(description = "Status do Drone") @RequestParam(name = "status", required = false) final String status,
            @Parameter(description = "Descrição do Sistema") @RequestParam(name = "sistema.descricao", required = false) final String sistemaDescricao,
            @Parameter(description = "Descrição da Localização") @RequestParam(name = "localizacao.descricao", required = false) final String localizacaoDescricao
    ) {
        var sistema = Sistema.builder()
                .descricao(sistemaDescricao)
                .build();
        var localizacao = Localizacao.builder()
                .descricao(localizacaoDescricao)
                .build();

        Set<Localizacao> localizacoes = new LinkedHashSet<>();
        localizacoes.add(localizacao);

        var dro = Drone.builder()
                .modeloDrone(modelo)
                .localizacaoAtual(localizacaoAtual)
                .status(status)
                .sistema(sistema)
                .localizacao(localizacoes)
                .build();

        ExampleMatcher matcher = ExampleMatcher
                .matchingAll()
                .withIgnoreNullValues()
                .withIgnoreCase()
                .withMatcher("sistema.descricao", ExampleMatcher.GenericPropertyMatchers.contains())
                .withMatcher("localizacao.descricao", ExampleMatcher.GenericPropertyMatchers.contains());

        Example<Drone> example = Example.of(dro, matcher);

        var entity = service.findAll(example);

        var response = entity.stream().map(service::toResponse).toList();

        return ResponseEntity.ok(response);
    }

    @GetMapping(value = "/{id}")
    @Operation(summary = "Buscar Drone por ID", description = "Retorna um drone baseado no ID fornecido")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Sucesso"),
            @ApiResponse(responseCode = "404", description = "Drone não encontrado"),
            @ApiResponse(responseCode = "500", description = "Erro interno do servidor")
    })
    @Override
    public ResponseEntity<DroneResponse> findById(@PathVariable @Parameter(description = "ID do Drone", required = true) final Long id) {
        var entity = service.findById(id);
        if (Objects.isNull(entity)) return ResponseEntity.notFound().build();
        var response = service.toResponse(entity);
        return ResponseEntity.ok(response);
    }

    @Transactional
    @PostMapping
    @Operation(summary = "Criar novo Drone", description = "Cria um novo drone com base nos dados fornecidos")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Drone criado com sucesso"),
            @ApiResponse(responseCode = "400", description = "Dados inválidos fornecidos"),
            @ApiResponse(responseCode = "500", description = "Erro interno do servidor")
    })
    @Override
    public ResponseEntity<DroneResponse> save(@RequestBody @Valid @Parameter(description = "Dados do Drone", required = true) DroneRequest r) {
        var entity = service.toEntity(r);
        var saved = service.save(entity);
        var uri = ServletUriComponentsBuilder.fromCurrentRequestUri()
                .path("/{id}")
                .buildAndExpand(saved.getId())
                .toUri();

        AbstractRequest localizacaoRequest = r.localizacao().stream().findFirst().orElseThrow(
                () -> new IllegalArgumentException("Localização não informada")
        );
        var localizacao = localizacaoService.findById(localizacaoRequest.id());

        var localizacoes = new HashSet<Localizacao>();
        localizacoes.add(localizacao);
        saved.setLocalizacao(localizacoes);

        var response = service.toResponse(saved);
        return ResponseEntity.created(uri).body(response);
    }
}
