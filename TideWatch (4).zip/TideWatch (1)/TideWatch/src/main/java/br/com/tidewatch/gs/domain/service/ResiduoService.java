package br.com.tidewatch.gs.domain.service;

import br.com.tidewatch.gs.domain.dto.request.ResiduoRequest;
import br.com.tidewatch.gs.domain.dto.response.ResiduoResponse;
import br.com.tidewatch.gs.domain.entity.Residuo;
import br.com.tidewatch.gs.domain.repository.ResiduoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Service;

import java.util.Collection;

@Service
public class ResiduoService implements ServiceDTO<Residuo, ResiduoRequest, ResiduoResponse>{

    @Autowired
    private ResiduoRepository repo;

    @Autowired
    private DroneService droneService;
    @Override
    public Collection<Residuo> findAll() {
        return repo.findAll();
    }

    @Override
    public Collection<Residuo> findAll(Example<Residuo> example) {
        return repo.findAll(example);
    }

    @Override
    public Residuo findById(Long id) {
        return repo.findById( id ).orElse(null);
    }

    @Override
    public Residuo save(Residuo e) {
        return repo.save(e);
    }

    @Override
    public Residuo toEntity(ResiduoRequest dto) {
        var drone = droneService.findById(dto.drone().id());
        return Residuo.builder()
                .coleta(dto.coleta())
                .drone(drone)
                .quantidade(dto.quantidade())
                .residuos(dto.residuos())
                .tipo(dto.tipo())
                .build();

    }

    @Override
    public ResiduoResponse toResponse(Residuo e) {
        var drone = droneService.toResponse(e.getDrone());
        return ResiduoResponse.builder()
                .id(e.getId())
                .coleta(e.getColeta())
                .drone(drone)
                .quantidade(e.getQuantidade())
                .residuos(e.getResiduos())
                .tipo(e.getTipo())
                .build();
    }
}
