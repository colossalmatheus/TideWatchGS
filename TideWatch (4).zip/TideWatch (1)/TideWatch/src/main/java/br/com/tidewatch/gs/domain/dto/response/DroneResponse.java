package br.com.tidewatch.gs.domain.dto.response;

import lombok.Builder;

import java.util.Collection;

@Builder
public record DroneResponse(
        Long id,
        String localizacaoAtual,
        Collection<LocalizacaoResponse> localizacao,
        String modeloDrone,
        SistemaResponse sistema,
        String status
) {
}
