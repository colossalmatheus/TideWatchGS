package br.com.tidewatch.gs.domain.entity;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder

@Entity
@Table(name = "T_SISTEMA")
public class Sistema {
    @Id
    @SequenceGenerator(name = "SQ_SISTEMA", sequenceName = "SQ_SISTEMA", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SQ_SISTEMA")
    @Column(name = "ID_SISTEMA")
    private Long id;

    @Column(name = "ST_SISTEMA")
    private String status;

    @Column(name = "DS_SISTEMA")
    private String descricao;

    @Column(name = "TP_SISTEMA")
    private String tipo;

}
