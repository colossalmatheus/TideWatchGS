package br.com.tidewatch.gs.domain.service;

import br.com.tidewatch.gs.domain.dto.request.EmbarcacaoRequest;
import br.com.tidewatch.gs.domain.dto.response.EmbarcacaoResponse;
import br.com.tidewatch.gs.domain.dto.response.LocalizacaoResponse;
import br.com.tidewatch.gs.domain.dto.response.ResiduoResponse;
import br.com.tidewatch.gs.domain.entity.Embarcacao;
import br.com.tidewatch.gs.domain.entity.Localizacao;
import br.com.tidewatch.gs.domain.entity.Residuo;
import br.com.tidewatch.gs.domain.repository.DroneRepository;
import br.com.tidewatch.gs.domain.repository.EmbarcacaoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.Set;

@Service
public class EmbarcacaoService implements ServiceDTO<Embarcacao, EmbarcacaoRequest, EmbarcacaoResponse>{

    @Autowired
    private EmbarcacaoRepository repo;

    @Autowired
    private LocalizacaoService localizacaoService;

    @Autowired
    private ResiduoService residuoService;

    @Override
    public Collection<Embarcacao> findAll() {
        return repo.findAll();
    }

    @Override
    public Collection<Embarcacao> findAll(Example<Embarcacao> example) {
        return repo.findAll(example);
    }

    @Override
    public Embarcacao findById(Long id) {
        return repo.findById( id ).orElse(null);
    }

    @Override
    public Embarcacao save(Embarcacao e) {
        return repo.save(e);
    }

    @Override
    public Embarcacao toEntity(EmbarcacaoRequest dto) {
        Set<Localizacao> localizacao = new LinkedHashSet<>();
        Set<Residuo> residuo = new LinkedHashSet<>();
        return Embarcacao.builder()
                .descricao(dto.descricao())
                .nome(dto.nome())
                .status(dto.status())
                .tipo(dto.tipo())
                .localizacao(localizacao)
                .residuos(residuo)
                .build();
    }

    @Override
    public EmbarcacaoResponse toResponse(Embarcacao e) {
        Collection<LocalizacaoResponse> localizacoes = new LinkedHashSet<>();
        for(var localizacao:e.getLocalizacao()){
            localizacoes.add(localizacaoService.toResponse(localizacao));
        }
        Collection<ResiduoResponse> residuos = new LinkedHashSet<>();
        for(var residuo:e.getResiduos()){
            residuos.add(residuoService.toResponse(residuo));
        }
        return EmbarcacaoResponse.builder()
                .id(e.getId())
                .descricao(e.getDescricao())
                .nome(e.getNome())
                .status(e.getStatus())
                .tipo(e.getTipo())
                .localizacao(localizacoes)
                .residuos(residuos)
                .build();
    }
}
