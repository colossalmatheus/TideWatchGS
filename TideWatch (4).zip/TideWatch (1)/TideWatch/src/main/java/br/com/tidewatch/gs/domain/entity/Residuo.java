package br.com.tidewatch.gs.domain.entity;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder

@Entity
@Table(name = "T_RESIDUOS")
public class Residuo {

    @Id
    @SequenceGenerator(name = "SQ_RESIDUOS", sequenceName = "SQ_RESIDUOS", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SQ_RESIDUOS")
    @Column(name = "ID_RESIDUOS")
    private Long id;

    @Column(name = "TP_RESIDUOS")
    private String tipo;

    @Column(name = "DS_RESIDUOS")
    private String residuos;

    @Column(name = "DT_COLETA")
    private LocalDateTime coleta;

    @Column(name = "QNT_COLETADA")
    private String quantidade;

    @ManyToOne(fetch = FetchType.EAGER, cascade = {CascadeType.PERSIST, CascadeType.MERGE})
    @JoinColumn(
            name = "DRONE",
            referencedColumnName = "ID_DRONE",
            foreignKey = @ForeignKey(
                    name = "FK_RESIDUOS_DRONE"
            )
    )
    private Drone drone;
}
