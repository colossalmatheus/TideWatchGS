package br.com.tidewatch.gs.domain.resource;

import br.com.tidewatch.gs.domain.dto.request.MonitoramentoResquest;
import br.com.tidewatch.gs.domain.dto.response.MonitoramentoResponse;
import br.com.tidewatch.gs.domain.entity.Drone;
import br.com.tidewatch.gs.domain.entity.Monitoramento;
import br.com.tidewatch.gs.domain.service.MonitoramentoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.util.Collection;
import java.util.Objects;

@RestController
@RequestMapping(value = "/monitoramento")
public class MonitoramentoResource implements ResourceDTO<MonitoramentoResquest, MonitoramentoResponse> {

    @Autowired
    private MonitoramentoService service;

    @GetMapping
    @Operation(summary = "Listar todos os Monitoramentos", description = "Lista todos os monitoramentos com base nos parâmetros de filtro opcionais")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Sucesso"),
            @ApiResponse(responseCode = "400", description = "Parâmetro inválido"),
            @ApiResponse(responseCode = "500", description = "Erro interno do servidor")
    })
    public ResponseEntity<Collection<MonitoramentoResponse>> findAll(
            @Parameter(description = "Descrição do Monitoramento") @RequestParam(name = "descricao", required = false) final String descricao,
            @Parameter(description = "Status do Monitoramento") @RequestParam(name = "status", required = false) final String status,
            @Parameter(description = "Modelo do Drone") @RequestParam(name = "drone.modelo", required = false) final String droneModelo
    ) {
        var dro = Drone.builder()
                .modeloDrone(droneModelo)
                .build();
        var mon = Monitoramento.builder()
                .descricao(descricao)
                .status(status)
                .drone(dro)
                .build();

        ExampleMatcher matcher = ExampleMatcher
                .matchingAll()
                .withIgnoreNullValues()
                .withIgnoreCase();

        Example<Monitoramento> example = Example.of(mon, matcher);

        var entity = service.findAll(example);

        var response = entity.stream().map(service::toResponse).toList();

        return ResponseEntity.ok(response);
    }

    @GetMapping(value = "/{id}")
    @Operation(summary = "Buscar Monitoramento por ID", description = "Retorna um monitoramento baseado no ID fornecido")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Sucesso"),
            @ApiResponse(responseCode = "404", description = "Monitoramento não encontrado"),
            @ApiResponse(responseCode = "500", description = "Erro interno do servidor")
    })
    @Override
    public ResponseEntity<MonitoramentoResponse> findById(@PathVariable @Parameter(description = "ID do Monitoramento", required = true) final Long id) {
        var entity = service.findById(id);
        if (Objects.isNull(entity)) return ResponseEntity.notFound().build();
        var response = service.toResponse(entity);
        return ResponseEntity.ok(response);
    }

    @Transactional
    @PostMapping
    @Operation(summary = "Criar novo Monitoramento", description = "Cria um novo monitoramento com base nos dados fornecidos")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Monitoramento criado com sucesso"),
            @ApiResponse(responseCode = "400", description = "Dados inválidos fornecidos"),
            @ApiResponse(responseCode = "500", description = "Erro interno do servidor")
    })
    @Override
    public ResponseEntity<MonitoramentoResponse> save(@RequestBody @Valid @Parameter(description = "Dados do Monitoramento", required = true) MonitoramentoResquest r) {
        var entity = service.toEntity(r);
        var saved = service.save(entity);
        var uri = ServletUriComponentsBuilder.fromCurrentRequestUri()
                .path("/{id}")
                .buildAndExpand(saved.getId())
                .toUri();

        var response = service.toResponse(saved);

        return ResponseEntity.created(uri).body(response);
    }
}
