package br.com.tidewatch.gs.domain.service;

import br.com.tidewatch.gs.domain.dto.request.MonitoramentoResquest;
import br.com.tidewatch.gs.domain.dto.response.MonitoramentoResponse;
import br.com.tidewatch.gs.domain.entity.Monitoramento;
import br.com.tidewatch.gs.domain.repository.LocalizacaoRepository;
import br.com.tidewatch.gs.domain.repository.MonitoramentoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Service;

import java.util.Collection;

@Service
public class MonitoramentoService implements ServiceDTO<Monitoramento, MonitoramentoResquest, MonitoramentoResponse>{

    @Autowired
    private MonitoramentoRepository repo;

    @Autowired
    private DroneService droneService;
    @Override
    public Collection<Monitoramento> findAll() {
        return repo.findAll();
    }

    @Override
    public Collection<Monitoramento> findAll(Example<Monitoramento> example) {
        return repo.findAll(example);
    }

    @Override
    public Monitoramento findById(Long id) {
        return repo.findById( id ).orElse(null);
    }

    @Override
    public Monitoramento save(Monitoramento e) {
        return repo.save(e);
    }

    @Override
    public Monitoramento toEntity(MonitoramentoResquest dto) {
        var drone = droneService.findById(dto.drone().id());
        return Monitoramento.builder()
                .descricao(dto.descricao())
                .status(dto.status())
                .drone(drone)
                .build();

    }

    @Override
    public MonitoramentoResponse toResponse(Monitoramento e) {
        var drone = droneService.toResponse(e.getDrone());
        return MonitoramentoResponse.builder()
                .id(e.getId())
                .descricao(e.getDescricao())
                .status(e.getStatus())
                .drone(drone)
                .build();
    }
}
