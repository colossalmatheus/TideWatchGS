package br.com.tidewatch.gs.domain.dto.request;

import jakarta.validation.constraints.NotNull;

public record SistemaRequest(

        @NotNull(message = "Informe a descricao")
        String descricao,

        @NotNull(message = "Informe o status")
        String Status,

        @NotNull(message = "Informe o tipo do sistema")
        String tipo

) {
}
