package br.com.tidewatch.gs.domain.entity;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder

@Entity
@Table(name = "T_MONITORAMENTO")
public class Monitoramento {

    @Id
    @SequenceGenerator(name = "SQ_MONITORAMENTO", sequenceName = "SQ_MONITORAMENTO", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SQ_MONITORAMENTO")
    @Column(name = "ID_MONITORAMENTO")
    private Long id;

    @Column(name = "ST_MONITORAMENTO")
    private String status;

    @Column(name = "DS_MONITORAMENTO")
    private String descricao;

    @ManyToOne(fetch = FetchType.EAGER, cascade = {CascadeType.PERSIST, CascadeType.MERGE})
    @JoinColumn(
            name = "DRONE",
            referencedColumnName = "ID_DRONE",
            foreignKey = @ForeignKey(
                    name = "FK_MONITORAMENTO_DRONE"
            )
    )
    private Drone drone;

}
