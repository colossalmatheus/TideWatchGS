package br.com.tidewatch.gs.domain.dto.response;

import lombok.Builder;

@Builder
public record LocalizacaoResponse(
        Long id,
        String descricao,
        String latitude,
        String longitude

) {
}
