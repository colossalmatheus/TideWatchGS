package br.com.tidewatch.gs.domain.dto.request;

import jakarta.validation.constraints.NotNull;

import java.util.Collection;

public record EmbarcacaoRequest(

        Collection<AbstractRequest> residuos,

        Collection<AbstractRequest> localizacao,

        @NotNull(message = "Informe a descrição")
        String descricao,

        @NotNull(message = "Informe o nome")
        String nome,

        @NotNull(message = "Informe o status")
        String status,

        String tipo

) {
}
