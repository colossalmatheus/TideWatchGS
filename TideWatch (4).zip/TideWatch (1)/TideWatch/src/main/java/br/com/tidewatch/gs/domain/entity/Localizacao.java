package br.com.tidewatch.gs.domain.entity;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder

@Entity
@Table(name = "T_LOCALIZACOES")
public class Localizacao {

    @Id
    @SequenceGenerator(name = "SQ_LOCALIZACAO", sequenceName = "SQ_LOCALIZACAO", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SQ_LOCALIZACAO")
    @Column(name = "ID_LOCALIZACAO")
    private Long id;

    @Column(name = "LATITUDE")
    private String latitude;

    @Column(name = "LONGITUDE")
    private String longitude;

    @Column(name = "DS_LOCALIZACAO")
    private String descricao;

}
