package br.com.tidewatch.gs.domain.resource;

import br.com.tidewatch.gs.domain.dto.request.AbstractRequest;
import br.com.tidewatch.gs.domain.dto.request.EmbarcacaoRequest;
import br.com.tidewatch.gs.domain.dto.response.EmbarcacaoResponse;
import br.com.tidewatch.gs.domain.entity.Embarcacao;
import br.com.tidewatch.gs.domain.entity.Localizacao;
import br.com.tidewatch.gs.domain.entity.Residuo;
import br.com.tidewatch.gs.domain.service.EmbarcacaoService;
import br.com.tidewatch.gs.domain.service.LocalizacaoService;
import br.com.tidewatch.gs.domain.service.ResiduoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.util.*;

@RestController
@RequestMapping(value = "/embarcacao")
public class EmbarcacaoResource implements ResourceDTO<EmbarcacaoRequest, EmbarcacaoResponse> {

    @Autowired
    private EmbarcacaoService service;

    @Autowired
    private LocalizacaoService localizacaoService;

    @Autowired
    private ResiduoService residuoService;

    @GetMapping
    @Operation(summary = "Listar todas as Embarcações", description = "Lista todas as embarcações com base nos parâmetros de filtro opcionais")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Sucesso", content = @Content(array = @ArraySchema(schema = @Schema(implementation = EmbarcacaoResponse.class)))),
            @ApiResponse(responseCode = "400", description = "Parâmetro inválido"),
            @ApiResponse(responseCode = "500", description = "Erro interno do servidor")
    })
    public ResponseEntity<Collection<EmbarcacaoResponse>> findAll(
            @Parameter(description = "Descrição da Embarcação") @RequestParam(name = "descricao", required = false) final String descricao,
            @Parameter(description = "Nome da Embarcação") @RequestParam(name = "nome", required = false) final String nome,
            @Parameter(description = "Status da Embarcação") @RequestParam(name = "status", required = false) final String status,
            @Parameter(description = "Tipo da Embarcação") @RequestParam(name = "tipo", required = false) final String tipo,
            @Parameter(description = "Descrição dos Resíduos") @RequestParam(name = "residuos.residuos", required = false) final String residuos,
            @Parameter(description = "Descrição da Localização") @RequestParam(name = "localizacao.descricao", required = false) final String localizacaoDescricao
    ) {
        var residuo = Residuo.builder()
                .residuos(residuos)
                .build();
        var localizacao = Localizacao.builder()
                .descricao(localizacaoDescricao)
                .build();

        Set<Residuo> resi = new LinkedHashSet<>();
        resi.add(residuo);

        Set<Localizacao> localizacoes = new LinkedHashSet<>();
        localizacoes.add(localizacao);

        var emb = Embarcacao.builder()
                .descricao(descricao)
                .nome(nome)
                .status(status)
                .tipo(tipo)
                .localizacao(localizacoes)
                .residuos(resi)
                .build();

        ExampleMatcher matcher = ExampleMatcher
                .matchingAll()
                .withIgnoreNullValues()
                .withIgnoreCase();

        Example<Embarcacao> example = Example.of(emb, matcher);

        var entity = service.findAll(example);

        var response = entity.stream().map(service::toResponse).toList();

        return ResponseEntity.ok(response);
    }

    @GetMapping(value = "/{id}")
    @Operation(summary = "Buscar Embarcação por ID", description = "Retorna uma embarcação baseado no ID fornecido")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Sucesso", content = @Content(schema = @Schema(implementation = EmbarcacaoResponse.class))),
            @ApiResponse(responseCode = "404", description = "Embarcação não encontrada"),
            @ApiResponse(responseCode = "500", description = "Erro interno do servidor")
    })
    @Override
    public ResponseEntity<EmbarcacaoResponse> findById(@PathVariable @Parameter(description = "ID da Embarcação", required = true) final Long id) {
        var entity = service.findById(id);
        if (Objects.isNull(entity)) return ResponseEntity.notFound().build();
        var response = service.toResponse(entity);
        return ResponseEntity.ok(response);
    }

    @Transactional
    @PostMapping
    @Operation(summary = "Criar nova Embarcação", description = "Cria uma nova embarcação com base nos dados fornecidos")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Embarcação criada com sucesso", content = @Content(schema = @Schema(implementation = EmbarcacaoResponse.class))),
            @ApiResponse(responseCode = "400", description = "Dados inválidos fornecidos"),
            @ApiResponse(responseCode = "500", description = "Erro interno do servidor")
    })
    @Override
    public ResponseEntity<EmbarcacaoResponse> save(@RequestBody @Valid @Parameter(description = "Dados da Embarcação", required = true) EmbarcacaoRequest r) {
        var entity = service.toEntity(r);
        var saved = service.save(entity);
        var uri = ServletUriComponentsBuilder.fromCurrentRequestUri()
                .path("/{id}")
                .buildAndExpand(saved.getId())
                .toUri();

        // Adiciona a localização à entidade salva
        AbstractRequest localizacaoRequest = r.localizacao().stream().findFirst().orElseThrow(
                () -> new IllegalArgumentException("Localização não informada")
        );
        var localizacao = localizacaoService.findById(localizacaoRequest.id());
        var localizacoes = new HashSet<Localizacao>();
        localizacoes.add(localizacao);
        saved.setLocalizacao(localizacoes);

        // Adiciona os resíduos à entidade salva
        AbstractRequest residuoRequest = r.residuos().stream().findFirst().orElseThrow(
                () -> new IllegalArgumentException("Resíduo não informado")
        );
        var residuo = residuoService.findById(residuoRequest.id());
        var residuos = new HashSet<Residuo>();
        residuos.add(residuo);
        saved.setResiduos(residuos);

        var response = service.toResponse(saved);

        return ResponseEntity.created(uri).body(response);
    }
}
