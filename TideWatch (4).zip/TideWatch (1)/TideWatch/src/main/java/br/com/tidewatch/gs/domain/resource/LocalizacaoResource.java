package br.com.tidewatch.gs.domain.resource;

import br.com.tidewatch.gs.domain.dto.request.LocalizacaoRequest;
import br.com.tidewatch.gs.domain.dto.response.LocalizacaoResponse;
import br.com.tidewatch.gs.domain.entity.Localizacao;
import br.com.tidewatch.gs.domain.service.LocalizacaoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.util.Collection;
import java.util.Objects;

@RestController
@RequestMapping(value = "/localizacao")
public class LocalizacaoResource implements ResourceDTO<LocalizacaoRequest, LocalizacaoResponse> {

    @Autowired
    private LocalizacaoService service;

    @GetMapping
    @Operation(summary = "Listar todas as Localizações", description = "Lista todas as localizações com base nos parâmetros de filtro opcionais")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Sucesso"),
            @ApiResponse(responseCode = "400", description = "Parâmetro inválido"),
            @ApiResponse(responseCode = "500", description = "Erro interno do servidor")
    })
    public ResponseEntity<Collection<LocalizacaoResponse>> findAll(
            @Parameter(description = "Descrição da Localização") @RequestParam(name = "descricao", required = false) final String descricao,
            @Parameter(description = "Latitude da Localização") @RequestParam(name = "latitude", required = false) final String latitude,
            @Parameter(description = "Longitude da Localização") @RequestParam(name = "longitude", required = false) final String longitude
    ) {
        var local = Localizacao.builder()
                .descricao(descricao)
                .latitude(latitude)
                .longitude(longitude)
                .build();

        ExampleMatcher matcher = ExampleMatcher
                .matchingAll()
                .withIgnoreNullValues()
                .withIgnoreCase();

        Example<Localizacao> example = Example.of(local, matcher);

        var entity = service.findAll(example);

        var response = entity.stream().map(service::toResponse).toList();

        return ResponseEntity.ok(response);
    }

    @GetMapping(value = "/{id}")
    @Operation(summary = "Buscar Localização por ID", description = "Retorna uma localização baseado no ID fornecido")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Sucesso"),
            @ApiResponse(responseCode = "404", description = "Localização não encontrada"),
            @ApiResponse(responseCode = "500", description = "Erro interno do servidor")
    })
    @Override
    public ResponseEntity<LocalizacaoResponse> findById(@PathVariable @Parameter(description = "ID da Localização", required = true) final Long id) {
        var entity = service.findById(id);
        if (Objects.isNull(entity)) return ResponseEntity.notFound().build();
        var response = service.toResponse(entity);
        return ResponseEntity.ok(response);
    }

    @Transactional
    @PostMapping
    @Operation(summary = "Criar nova Localização", description = "Cria uma nova localização com base nos dados fornecidos")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Localização criada com sucesso"),
            @ApiResponse(responseCode = "400", description = "Dados inválidos fornecidos"),
            @ApiResponse(responseCode = "500", description = "Erro interno do servidor")
    })
    @Override
    public ResponseEntity<LocalizacaoResponse> save(@RequestBody @Valid @Parameter(description = "Dados da Localização", required = true) LocalizacaoRequest r) {
        var entity = service.toEntity(r);
        var saved = service.save(entity);
        var uri = ServletUriComponentsBuilder.fromCurrentRequestUri()
                .path("/{id}")
                .buildAndExpand(saved.getId())
                .toUri();

        var response = service.toResponse(saved);

        return ResponseEntity.created(uri).body(response);
    }
}
