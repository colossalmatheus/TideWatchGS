package br.com.tidewatch.gs.domain.service;

import br.com.tidewatch.gs.domain.dto.request.UsuarioRequest;
import br.com.tidewatch.gs.domain.dto.response.UsuarioResponse;
import br.com.tidewatch.gs.domain.entity.Usuario;
import br.com.tidewatch.gs.domain.repository.SistemaRepository;
import br.com.tidewatch.gs.domain.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Service;

import java.util.Collection;

@Service
public class UsuarioService implements ServiceDTO<Usuario, UsuarioRequest, UsuarioResponse>{

    @Autowired
    private UsuarioRepository repo;

    @Autowired
    private SistemaService sistemaService;
    @Override
    public Collection<Usuario> findAll() {
        return repo.findAll();
    }

    @Override
    public Collection<Usuario> findAll(Example<Usuario> example) {
        return repo.findAll(example);
    }

    @Override
    public Usuario findById(Long id) {
        return repo.findById( id ).orElse(null);
    }

    @Override
    public Usuario save(Usuario e) {
        return repo.save(e);
    }

    @Override
    public Usuario toEntity(UsuarioRequest dto) {
        var sistema = sistemaService.findById(dto.sistema().id());
        return Usuario.builder()
                .nome(dto.nome())
                .descricao(dto.descricao())
                .sistema(sistema)
                .build();
    }

    @Override
    public UsuarioResponse toResponse(Usuario e) {
        var sistema = sistemaService.toResponse(e.getSistema());
        return UsuarioResponse.builder()
                .id(e.getId())
                .descricao(e.getDescricao())
                .nome(e.getNome())
                .sistema(sistema)
                .build();
    }
}
