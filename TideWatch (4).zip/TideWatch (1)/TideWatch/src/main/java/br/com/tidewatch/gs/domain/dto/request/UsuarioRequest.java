package br.com.tidewatch.gs.domain.dto.request;

import jakarta.validation.constraints.NotNull;

public record UsuarioRequest(

        @NotNull(message = "Informe a descricao")
        String descricao,

        @NotNull(message = "Informe o nome")
        String nome,

       AbstractRequest sistema
) {
}
